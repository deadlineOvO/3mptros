#!/system/bin/sh

commands() {
	echo "install /mnt/$1/update.zip" > /cache/recovery/openrecoveryscript
	echo "cmd /sbin/sh /tmp/wipe.sh" >> /cache/recovery/openrecoveryscript
	chmod 644 /cache/recovery/openrecoveryscript
}

#挂载一些分区
mount -o remount /;
mount -o remount /data;
mount -o remount /cache;
#判断刷写文件
if [ -e "/storage/sdcard1/update.zip" ]; then
	commands "external_sd"
elif [ -e "/sdcard/update.zip" ]; then
	commands "sdcard"
fi
#准备进行最后一步
echo 即将进入 TWRP Recovery
nohup sh /data/shell/install+run_recovery.sh &
